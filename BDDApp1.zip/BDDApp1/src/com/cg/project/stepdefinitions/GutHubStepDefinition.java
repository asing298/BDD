package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GutHubStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	@Before 
	public void setUpEnv(){
		System.setProperty("webdriver.chrome.driver",
				"C:\\BDD-Cucumber\\chromedriver\\chromedriver.exe");
		
		
	}
	@Given("^User is on Github login Page$")
	public void user_is_on_Github_login_Page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://www.github.com/login");
		
		loginPage=PageFactory.initElements(driver,LoginPage.class);
		
	}

	@When("^user enter Invalid username and password$")
	public void user_enter_Invalid_username_and_password() throws Throwable {
	   loginPage.setUsername("ankit2987");
	   loginPage.setPassword("ankit");
	   loginPage.clickSignIn();
	   
	   }

	@Then("^'Incorrect username and password\\.'Message should display$")
	public void incorrect_username_and_password_Message_should_display() throws Throwable {
		
		 String expectedErrorMeassage="Incorrect username or password.";
		 Assert.assertEquals(expectedErrorMeassage,loginPage.getActualErrorMessage());
	}

	@When("^user enters valid username and password$")
	public void user_enters_valid_username_and_password() throws Throwable {
		  loginPage.setUsername("himanshusrivastava2210");
		   loginPage.setPassword("hunnybunny2210");
		   loginPage.clickSignIn();
	}

	@Then("^user sholud successfully Signin on His GitHub Account$")
	public void user_sholud_successfully_Signin_on_His_GitHub_Account() throws Throwable {
		String actualTitle =driver.getTitle();
		 String expectedTitle="GitHub";
		 Assert.assertEquals(expectedTitle, actualTitle);
		 
		 driver.close();
	}


	
	
	
	
}
