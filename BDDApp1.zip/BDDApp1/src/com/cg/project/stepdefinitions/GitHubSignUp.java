package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.github.pagebeans.SignUp;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubSignUp {
	private WebDriver driver;
	private SignUp signUp;
	@Before
	public void setUpEnv(){
		System.setProperty("webdriver.chrome.driver",
				"C:\\BDD-Cucumber\\chromedriver\\chromedriver.exe");
	}
		
		
		
	@Given("^User is on Github sign up Page$")
	public void user_is_on_Github_sign_up_Page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://github.com/join");
		
		signUp=PageFactory.initElements(driver,SignUp.class);
	}

	@When("^user enter Invalid username$")
	public void user_enter_Invalid_username() throws Throwable {
		signUp.setUsername("himanshusrivastava");
		
		
		signUp.clickSignup();
	}

	@When("^user enter Invalid Password$")
	public void user_enter_Invalid_Password() throws Throwable {
		signUp.setPassword("ank");
		signUp.clickSignup();
	}

	@When("^user enter Invalid email$")
	public void user_enter_Invalid_email() throws Throwable {
		signUp.setEmail("ankit.i.singh@capgemini.com");
		signUp.clickSignup();
	}

	@Then("^'Login is already taken'Message should display$")
	public void username_is_already_taken_Message_should_display() throws Throwable {

		 String expectedErrorMeassage="Login is already taken";
		 Assert.assertEquals(expectedErrorMeassage,signUp.getActualErrorMessage());
		 driver.close();
	}

	@Then("^'Password is too short \\(minimum is (\\d+) characters\\), needs at least (\\d+) lowercase letter, cannot include your login, and is weak and can be easily guessed'Message should displa$")
	public void password_is_too_short_minimum_is_characters_needs_at_least_lowercase_letter_cannot_include_your_login_and_is_weak_and_can_be_easily_guessed_Message_should_displa(int arg1, int arg2) throws Throwable {

		 String expectedErrorMeassage="Password is too short \\(minimum is (\\d+) characters\\), needs at least (\\d+) lowercase letter, cannot include your login, and is weak and can be easily guessed";
		 Assert.assertEquals(expectedErrorMeassage,signUp.getActualErrorMessage1());
		 driver.close();
	}

	@Then("^'Email is invalid or already taken'Message should display$")
	public void email_is_invalid_or_already_taken_Message_should_display() throws Throwable {
		 String expectedErrorMeassage="Email is invalid or already taken";
		 Assert.assertEquals(expectedErrorMeassage,signUp.getActualErrorMessage2());
		 driver.close();
	}

	@When("^user enters valid username$")
	public void user_enters_valid_username() throws Throwable {
	signUp.setUsername("ankit12007");
		
		
		signUp.clickSignup();
	}

	@When("^user enters valid password$")
	public void user_enters_valid_password() throws Throwable {
		signUp.setPassword("AnkitSingh123@");
		signUp.clickSignup();
	}

	@When("^user enters valid email$")
	public void user_enters_valid_email() throws Throwable {
		signUp.setEmail("ankit12007@gmail.com");
		signUp.clickSignup();
	}

	@Then("^user sholud successfully Signup on His GitHub Account$")
	public void user_sholud_successfully_Signup_on_His_GitHub_Account() throws Throwable {
		String actualTitle =driver.getTitle();
		 String expectedTitle="Join GitHub � GitHub";
		 Assert.assertEquals(expectedTitle, actualTitle);
		 
		 driver.close();
	}
	
	

}
